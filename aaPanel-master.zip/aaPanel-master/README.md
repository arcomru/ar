##### Forum address：https://forum.aapanel.com/
##### Feedback： https://forum.aapanel.com/
##### Bug submission：https://forum.aapanel.com/

#### Installation command：
##### Centos
```bash
yum install -y wget && wget -O install.sh http://www.aapanel.com/script/install_6.0_en.sh && bash install.sh
```
##### Ubuntu/Debian
```bash
wget -O install.sh http://www.aapanel.com/script/install-ubuntu_6.0_en.sh && sudo bash install.sh
```
